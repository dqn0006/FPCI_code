
import cdsapi
import pandas as pd
import os
import urllib.request
import ssl
import time

# 禁用 SSL 验证（用于特定网络下的 SSL 证书问题）
ssl._create_default_https_context = ssl._create_unverified_context

# 初始化 CDS API 客户端
cds = cdsapi.Client()

# 生成 2014 年的每日日期
df = pd.DataFrame([])
df['date'] = pd.date_range('2015-01-01', '2015-12-31', freq='D')  # 每日日期
df['mth'] = [str(x).zfill(2) for x in df['date'].dt.month]  # 月份两位数
df['day'] = [str(x).zfill(2) for x in df['date'].dt.day]    # 日期两位数

# 确保输出目录存在
output_dir = r'H:\ECNUtitle\Fish\Fish_code\fpvGSEE-main\ERA5_data\2004_2023_1\2015\0_dloaded_2015'
os.makedirs(output_dir, exist_ok=True)

# 读取 workflow.py 文件，并指定 utf-8 编码
workflow_fname = "workflow.py"
with open(workflow_fname, encoding='utf-8') as f:
    workflow_code = f.read()


# 遍历每一天的日期
for index, row in df.iterrows():
    mth = row['mth']
    day = row['day']

    # 生成文件路径
    fname = os.path.join(output_dir, f'srad_2015_{mth}_{day}.nc')

    # 如果文件已存在，跳过
    if os.path.isfile(fname):
        print(f"文件 {fname} 已存在，跳过下载。")
        continue

    # 替换 workflow.py 中的月份和日期标记
    workflow_code_new = workflow_code.replace('MM', mth).replace('DD', day)

    try:
        # 调用 workflow 生成数据链接
        r = cds.workflow(workflow_code_new)
        link = r[0].get('location')

        # 下载数据
        urllib.request.urlretrieve(link, fname)
        print(f"成功下载 2015-{mth}-{day} 的数据到 {fname}")
    except Exception as e:
        print(f"下载 2015-{mth}-{day} 数据时出错: {e}")

    # 添加延时以避免请求过多
    time.sleep(1)



'''
import cdsapi
import pandas as pd
import urllib.request
import ssl
import os
import time

# 初始化 CDS API 客户端
cds = cdsapi.Client()

# 禁用 SSL 验证（可能用于绕过企业或特定网络下的 SSL 证书问题）
ssl._create_default_https_context = ssl._create_unverified_context

# 生成 2020 年的每日日期
df = pd.DataFrame([])
df['date'] = pd.date_range('2020-01-01 00:00', '2020-12-31 23:00', freq='D')
df['mth'] = [str(x).zfill(2) for x in df['date'].dt.month]
df['day'] = [str(x).zfill(2) for x in df['date'].dt.day]

# 读取工作流代码模板
fname = "workflow.py"
with open(fname, encoding='utf-8') as f:
    code = f.read()

# 确保输出目录存在
output_dir = r'H:\ECNUtitle\Fish\Fish_code\fpvGSEE-main\ERA5_data\0_dloaded'
os.makedirs(output_dir, exist_ok=True)

# 定义下载函数，包含重试机制
def redownload(url, filename, max_retries=5, delay=10):
    """递归重试下载函数
    
    Args:
        url (str): 下载链接
        filename (str): 保存的文件路径
        max_retries (int): 最大重试次数
        delay (int): 每次重试前的等待时间（秒）
    """
    attempt = 0
    while attempt < max_retries:
        try:
            print(f"Attempting to download {filename} (Attempt {attempt + 1} of {max_retries})...")
            urllib.request.urlretrieve(url, filename)
            print(f"Download succeeded: {filename}")
            return
        except urllib.error.ContentTooShortError as e:
            attempt += 1
            print(f"Download failed: {e}. Retrying in {delay} seconds...")
            time.sleep(delay)  # 等待一段时间后再重试
        except Exception as e:
            print(f"An error occurred: {e}. Retrying in {delay} seconds...")
            time.sleep(delay)
            attempt += 1
    
    print(f"Failed to download {filename} after {max_retries} attempts.")
    raise Exception(f"Failed to download {filename} after multiple retries.")

# 遍历每一天的日期
for index, row in df.iterrows():
    mth = row['mth']
    day = row['day']

    # 生成文件路径
    fname = os.path.join(output_dir, f'srad_{mth}_{day}.nc')
    
    if os.path.isfile(fname):
        continue  # 如果文件已存在，则跳过

    # 替换模板中的月份和日期
    code_new = code.replace('MM', mth).replace('DD', day)

    # 发送请求并获取下载链接
    r = cds.workflow(code_new)
    link = r[0].get('location')

    # 使用下载函数尝试下载文件
    redownload(link, fname)



import cdsapi
cds = cdsapi.Client()
import pandas as pd

import urllib.request
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
import os
import time

df = pd.DataFrame([])
df['date'] = pd.date_range('2020-01-01 00:00','2020-12-31 23:00',freq='D')
df['mth'] = [str(x).zfill(2) for x in df['date'].dt.month]
df['day'] = [str(x).zfill(2) for x in df['date'].dt.day]

fname = "workflow.py"
with open(fname) as f:
    code = f.read()

for index,row in df.iterrows():
    mth = row['mth']
    day = row['day']
    #hour = row['hour']

    fname = '0_dloaded/fdir_' + mth + '_' + day + '.nc'
    if os.path.isfile(fname):
        continue

    code_new = code.replace('MM', mth).replace('DD', day) #.replace('HH', hour)

    r = cds.workflow(code_new)
    link = r[0].get('location')

    urllib.request.urlretrieve(link, fname)
'''