import xarray as xr
from datetime import datetime, timedelta
import glob
import numpy as np
import os
import dask

# # 定义函数来调整经度范围
# def adjust_longitude(ds):
#     ds = ds.copy()
#     ds['longitude'] = ds['longitude'] % 360
#     ds = ds.sortby('longitude')
#     return ds

# # 定义函数来去除重复的时间维度并排序时间
# def process_and_check_time(ds, var_name):"""  """
#     ds = ds.sortby('time')  # 保证时间排序
#     _, index = np.unique(ds['time'], return_index=True)
#     ds = ds.isel(time=index)
#     return ds

with dask.config.set(**{'array.slicing.split_large_chunks': True}):

        # 加载 t2m 数据
        fnames = sorted(glob.glob(
            r'H:\ECNUtitle\Fish\Fish_code\fpvGSEE-main\ERA5_data\2004_2023\2014\2m_temperature\t2m_2014*.nc'))

        t2m_output = []

        for fname in fnames:
            try:
                base_name = os.path.basename(fname)
                date_str = base_name.split('_')[-1].replace('.nc', '')
                mdate = datetime.strptime(date_str, '%Y%m%d')


                ds = xr.open_dataset(fname, chunks='auto')

                if 'realization' in ds.variables:
                    ds = ds.drop_vars('realization')

                if 't2m' in ds.variables:
                    ds['t2m'] = ds['t2m'] - 273.15  # K 转换为 摄氏度
                else:
                    print(f"Warning: 't2m' not found in {fname}. Skipping this file.")
                    continue

                hours_in_day = 24
                time_values = [mdate + timedelta(hours=h) for h in range(hours_in_day)]
                ds['time'] = ('time', time_values)

                t2m_output.append(ds)
            except Exception as e:
                print(f"Error processing filename {fname}: {e}")
                continue


        temp_data = xr.concat(t2m_output, dim='time')
        # print("原始数据范围：",temp_data)
        # 选择 latitude 在 -65 到 65 之间的数据
        ds_subset_tm = temp_data.where((temp_data['latitude'] >= -65) & (temp_data['latitude'] <= -45), drop=True)
        # print("裁剪后数据范围：",ds_subset_tm)



        # 加载并处理 ssrd 数据
        fnames = sorted(glob.glob(
            r'H:\ECNUtitle\Fish\Fish_code\fpvGSEE-main\ERA5_data\2004_2023\2014\surface_solar_radiation_downwards\srad_2014*.nc'))

        ssrd_output = []

        for fname in fnames:
            try:
                base_name = os.path.basename(fname)
                date_str = base_name.split('_')[-1].replace('.nc', '')
                mdate = datetime.strptime(date_str, '%Y%m%d')

                ds = xr.open_dataset(fname, chunks='auto')

                if 'realization' in ds.variables:
                    ds = ds.drop_vars('realization')

                if 'ssrd' in ds.variables:
                    ds['ssrd'] = ds['ssrd'] / 3600  # 将 J/m² 转换为 W/m²
                else:
                    print(f"Warning: 'ssrd' not found in {fname}. Skipping this file.")
                    continue

                time_values = [mdate + timedelta(hours=h) for h in range(hours_in_day)]
                ds['time'] = ('time', time_values)

                ssrd_output.append(ds)
            except Exception as e:
                print(f"Error processing filename {fname}: {e}")
                continue

        ssrd_data = xr.concat(ssrd_output, dim='time')

        # print("原始数据范围：",ssrd_data)
        # 选择 latitude 在 -65 到 65 之间的数据
        ds_subset_ssrd = ssrd_data.where((ssrd_data['latitude'] >= -65) & (ssrd_data['latitude'] <= -45), drop=True)
        # print("裁剪后数据范围：",ds_subset_ssrd)

        # 加载并处理 fdir 数据
        fnames = sorted(glob.glob(
            r'H:\ECNUtitle\Fish\Fish_code\fpvGSEE-main\ERA5_data\2004_2023\2014\total_sky_direct_solar_radiation_at_surface\fdir_2014*.nc'))

        fdir_output = []

        for fname in fnames:
            try:
                base_name = os.path.basename(fname)
                date_str = base_name.split('_')[-1].replace('.nc', '')
                mdate = datetime.strptime(date_str, '%Y%m%d')

                ds = xr.open_dataset(fname, chunks='auto')

                if 'realization' in ds.variables:
                    ds = ds.drop_vars('realization')

                if 'fdir' not in ds.variables:
                    print(f"Warning: 'fdir' not found in {fname}. Skipping this file.")
                    continue

                time_values = [mdate + timedelta(hours=h) for h in range(hours_in_day)]
                ds['time'] = ('time', time_values)

                fdir_output.append(ds)
            except Exception as e:
                print(f"Error processing filename {fname}: {e}")
                continue

        fdir_data = xr.concat(fdir_output, dim='time')

        # print("原始数据范围：",fdir_data)
        # 选择 latitude 在 -65 到 65 之间的数据
        ds_subset_fdir = fdir_data.where((fdir_data['latitude'] >= -65) & (fdir_data['latitude'] <= -45), drop=True)
        # print("裁剪后数据范围：",ds_subset_fdir)

        # 对齐 ssrd 和 fdir 的时间维度
        ssrd_data_aligned, fdir_data_aligned = xr.align(ds_subset_ssrd, ds_subset_fdir, join='inner')

        # 计算 dfrac，避免除以 0
        valid_mask = (ssrd_data_aligned['ssrd'] > 0) & (fdir_data_aligned['fdir'] > 0)
        ssrd_valid = ssrd_data_aligned['ssrd'].where(valid_mask, other=1e-10)  # 避免 ssrd_valid 中的 0
        fdir_valid = fdir_data_aligned['fdir'].where(valid_mask)

        # 使用 xr.where 避免除以 0，并处理 NaN 值
        dfrac_data = 1 - (fdir_valid / ssrd_valid).clip(0, 1).fillna(0).rename('dfrac')

        # 保存 ssrd, t2m 和 dfrac 数据
        for mlat in sorted(ssrd_data_aligned['latitude'].values):
            ssrd_tmp = ssrd_data_aligned['ssrd'].sel(latitude=mlat)
            temp_tmp = ds_subset_tm['t2m'].sel(latitude=mlat)
            dfrac_tmp = dfrac_data.sel(latitude=mlat)

            # 将纬度添加为坐标维度
            ssrd_tmp = ssrd_tmp.expand_dims('latitude').assign_coords(latitude=[mlat])
            temp_tmp = temp_tmp.expand_dims('latitude').assign_coords(latitude=[mlat])
            dfrac_tmp = dfrac_tmp.expand_dims('latitude').assign_coords(latitude=[mlat])

            # 文件路径
            ssrd_fname = f'H:/ECNUtitle/Fish/Fish_code/fpvGSEE-main/ERA5_data/2004_2023_1/2014/tmp_data/era5_ssrd_{mlat}.nc'
            t2m_fname = f'H:/ECNUtitle/Fish/Fish_code/fpvGSEE-main/ERA5_data/2004_2023_1/2014/tmp_data/era5_t2m_{mlat}.nc'
            dfrac_fname = f'H:/ECNUtitle/Fish/Fish_code/fpvGSEE-main/ERA5_data/2004_2023_1/2014/tmp_data/era5_dfrac_{mlat}.nc'

            # 保存数据集，确保纬度作为一个坐标维度
            if not os.path.isfile(ssrd_fname) and not ssrd_tmp.isnull().all():
                ssrd_tmp.to_netcdf(ssrd_fname, encoding={'ssrd': dict(zlib=True, complevel=5)})

            if not os.path.isfile(t2m_fname) and not temp_tmp.isnull().all():
                temp_tmp.to_netcdf(t2m_fname, encoding={'t2m': dict(zlib=True, complevel=5)})

            if not os.path.isfile(dfrac_fname) and not dfrac_tmp.isnull().all():
                dfrac_tmp.to_netcdf(dfrac_fname, encoding={'dfrac': dict(zlib=True, complevel=5)})
