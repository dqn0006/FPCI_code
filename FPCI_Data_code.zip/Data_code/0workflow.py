import cdstoolbox as ct


@ct.application(title='Download data')
@ct.output.download()
def application():
    # 动态获取 ERA5 数据
    data = ct.catalogue.retrieve(
        'reanalysis-era5-single-levels',
        {
            'product_type': 'reanalysis',
            'variable': 'surface_solar_radiation_downwards',  # 请求表面太阳辐射向下量
            'year': ['2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023'],
            'month': 'MM',  # 月份占位符
            'day': 'DD',  # 日期占位符
            'time': [
                '00:00', '01:00', '02:00', '03:00', '04:00', '05:00',
                '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
                '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
                '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'
            ]
        }
    )

    # 按小时分组并计算日平均
    data_daily = ct.cube.groupby_reduce(data, group='time.hour', how='mean', dim='time')

    return data_daily


'''
import cdstoolbox as ct

@ct.application(title='Download data')
@ct.output.download()

def application():
    data = ct.catalogue.retrieve(
        'reanalysis-era5-single-levels',
        {
            'product_type': 'reanalysis',

            #'variable': '2m_temperature',  # 仅请求 ssrd
            'variable': 'surface_solar_radiation_downwards',  # 选择 srad 变量




            'year': [

                '2013', '2014', '2015', '2016',
                '2017', '2018', '2019', '2020',
                '2021', '2022', '2023',
            ],
            'month': 'MM',
            'day': 'DD',
            'time': [
                '00:00', '01:00', '02:00',
                '03:00', '04:00', '05:00',
                '06:00', '07:00', '08:00',
                '09:00', '10:00', '11:00',
                '12:00', '13:00', '14:00',
                '15:00', '16:00', '17:00',
                '18:00', '19:00', '20:00',
                '21:00', '22:00', '23:00',
            ],
        }
    )
    data_daily = ct.cube.groupby_reduce(data, group='time.hour', how='mean', dim='time')
    return data_daily

'''