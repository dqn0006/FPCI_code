import xarray as xr
import pandas as pd
import geopandas as gpd
import numpy as np
import os
import glob
import matplotlib.pyplot as plt
from cartopy import crs as ccrs

# 设置字体和字体大小
plt.rcParams["font.family"] = "Arial"
plt.rcParams.update({'font.size': 17})

# 获取并排序文件列表
files = sorted(glob.glob(r'H:\ECNUtitle\Fish\Fish_code\fpvGSEE-main\ERA5_data\2004_2023_1\2014\tmp_data\*_pv_*.nc'))
files = [c for c in files if np.float64(c.split('_')[-1].replace('.nc', '')) <= 5.2]

# 处理每个文件
for file in files:
    nname = file.replace('tmp_data', 'tmp_data1')
    if os.path.exists(nname):
        continue

    mdata = xr.open_dataset(file, chunks='auto')
    mdata_day = mdata.resample(time='1D').mean('time')

    print(f"Processing and saving: {nname}")
    mdata_day.to_netcdf(nname, encoding={'pv': dict(zlib=True, complevel=5)})

# 检查合并文件路径是否正确
merged_files = sorted(glob.glob(r'H:\ECNUtitle\Fish\Fish_code\fpvGSEE-main\ERA5_data\2004_2023_1\2014\tmp_data1\*_pv_*.nc'))
print(f"Files to be merged: {merged_files}")

if not merged_files:
    raise OSError("No files found to open in tmp_data1")

# 合并日平均数据
mdata_day = xr.open_mfdataset(merged_files)

# 保存合并后的日数据
mdata_day.to_netcdf('era5_pv_tilt15_day.nc', encoding={'pv': dict(zlib=True, complevel=5)})

# 计算月总量并转换单位
mdata_day = xr.open_dataset('era5_pv_tilt15_day.nc', chunks='auto')
mdata_mth = mdata_day.groupby('time.month').sum('time')
mdata_mth = mdata_mth * 24 / 1000  # 转换单位为kWh

# 保存月总量数据
mdata_mth.to_netcdf('era5_pv_tilt15_mthSum.nc', encoding={'pv': dict(zlib=True, complevel=5)})

# 使用新的地理边界文件路径
world_file = r'E:\Arcgisdata\OWF2022\全国风电制图\bound\世界地图shp\世界地图shp\世界地图.shp'

# 检查地理边界文件是否存在
if not os.path.isfile(world_file):
    raise FileNotFoundError(f"{world_file} not found. Please check the file path.")

# 读取地理边界文件
world = gpd.read_file(world_file)

# 读取月总量数据
mdata_mth = xr.open_dataset('era5_pv_tilt15_mthSum.nc')

# 绘图
fig, ax = plt.subplots(1, 1, figsize=(20, 10), subplot_kw={'projection': ccrs.PlateCarree()})

# 添加颜色条
cax = ax.inset_axes(bounds=[1.02, 0.0, 0.02, 1])
cbar_kwargs = {'orientation': 'vertical', 'cax': cax}

# 绘制地图和PV数据
mdata_mth.isel(month=7)['pv'].plot.pcolormesh(ax=ax, cmap='BrBG_r', add_colorbar=True, cbar_kwargs=cbar_kwargs)
world.boundary.plot(linewidth=1, color='k', ax=ax)

ax.coastlines()
ax.set_title('Monthly PV Generation for July')

plt.show()
