if __name__ == '__main__':
    from gsee.climatedata_interface.interface import run_interface
    import xarray as xr
    import glob
    import numpy as np
    import pandas as pd
    import os

    def tilt2(lat):
        if np.abs(lat) <= 15:
            mtilt = lat
        else:
            mtilt = 15 * np.abs(lat) / lat
        return mtilt

    # 获取符合纬度范围的文件列表
    for ssrd_fname in sorted(glob.glob('H:/ECNUtitle/Fish/Fish_code/fpvGSEE-main/ERA5_data/tmp_data/1/era5_ssrd_*.nc')):
        mlat = np.float64(ssrd_fname.split('_')[-1].replace('.nc', ''))

        # 只处理纬度在0到5度之间的数据
        if not (-7<= mlat <= -5):
            continue

        t2m_fname = ssrd_fname.replace('ssrd', 't2m')
        dfrac_fname = ssrd_fname.replace('ssrd', 'dfrac')
        pv_fname = ssrd_fname.replace('ssrd', 'pv')

        ssrd_fname_converted = ssrd_fname.replace('ssrd', 'ssrd_converted')
        t2m_fname_converted = t2m_fname.replace('t2m', 't2m_converted')
        dfrac_fname_converted = dfrac_fname.replace('dfrac', 'dfrac_converted')

        if all(os.path.exists(fname) for fname in
               [ssrd_fname_converted, t2m_fname_converted, dfrac_fname_converted, pv_fname]):
            print(f"All converted files and PV file for {mlat} already exist, skipping...")
            continue

        mtilt = tilt2(mlat)

        # 加载数据集
        ssrd_data = xr.open_dataset(ssrd_fname)
        t2m_data = xr.open_dataset(t2m_fname)
        dfrac_data = xr.open_dataset(dfrac_fname)

        # 打印数据维度
        print("SSRD Dimensions:", ssrd_data.dims)
        print("T2M Dimensions:", t2m_data.dims)
        print("DFRAC Dimensions:", dfrac_data.dims)

        # 检查时间维度一致性
        if not ssrd_data['time'].equals(t2m_data['time']):
            raise ValueError(f"Time dimensions of ssrd and t2m datasets are not consistent for {mlat}")
        if not ssrd_data['time'].equals(dfrac_data['time']):
            raise ValueError(f"Time dimensions of ssrd and dfrac datasets are not consistent for {mlat}")

        # 检查纬度和经度一致性
        if not ssrd_data['lat'].equals(t2m_data['lat']) or not ssrd_data['lon'].equals(t2m_data['lon']):
            print(f"Aligning T2M data with SSRD data for {mlat}")
            t2m_data = t2m_data.interp_like(ssrd_data)

        if not ssrd_data['lat'].equals(dfrac_data['lat']) or not ssrd_data['lon'].equals(dfrac_data['lon']):
            print(f"Aligning DFRAC data with SSRD data for {mlat}")
            dfrac_data = dfrac_data.interp_like(ssrd_data)

        # 检查时间频率是不是小时级别
        inferred_freq = pd.infer_freq(pd.DatetimeIndex(ssrd_data['time'].values)).upper()  # 将推断的频率转换为大写
        if inferred_freq != 'H':
            raise ValueError(f"Detected frequency is not hourly ('H'), but {inferred_freq} for {mlat}")

        print(f"Detected hourly frequency for {mlat}")

        # 保存转换后的数据集到临时文件
        ssrd_data.to_netcdf(ssrd_fname_converted)
        t2m_data.to_netcdf(t2m_fname_converted)
        dfrac_data.to_netcdf(dfrac_fname_converted)

        # 手动指定频率为 'H'（小时级别）
        run_interface(
            (ssrd_fname_converted, 'ssrd'),
            pv_fname,
            params=dict(tilt=mtilt, azim=180, tracking=0, capacity=1000),
            frequency='detect',
            diffuse_data=(dfrac_fname_converted, 'dfrac'),
            temp_data=(t2m_fname_converted, 't2m'),
            timeformat=None,
            pdfs_file=None,
            num_cores=1
        )
